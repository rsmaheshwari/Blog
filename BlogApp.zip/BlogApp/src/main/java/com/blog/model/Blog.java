package com.blog.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@Entity
@Table(name = "blogs")
public class Blog {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String title;

	@Column(length = 2000, nullable = false)
	private String content;

	private String category;

	@Column(name = "is_draft", nullable = false)
	private Boolean isDraft = true;

	@Column(name = "published_at")
	private LocalDateTime publishedAt;

	@ManyToOne(cascade = { CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.LAZY)
	@JoinColumn(name = "author_id", nullable = false)
	private UserProfile author;

	@ManyToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "blog_tags", // Join table for the relationship
			joinColumns = @JoinColumn(name = "blog_id"), // Foreign key to Blog
			inverseJoinColumns = @JoinColumn(name = "user_id") // Foreign key to UserProfile
	)
	private List<UserProfile> tags = new ArrayList<>();

	@OneToMany(mappedBy = "blog", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Comment> comments;
	
	@Override
	public String toString() {
		return "Blog [id=" + id + ", title=" + title + ", content=" + content + ", category=" + category + ", isDraft="
				+ isDraft + ", publishedAt=" + publishedAt + ", author id=" + author.getId() + ", tagged user id=" + tags.stream().map(tag->tag.getId()).toString() + ", comments count="
				+ comments.size() + "]";
	}

}
