package com.blog.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "user_profiles")
public class UserProfile {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;// user id

	@Column(nullable = false)
	private String name;

	@Column(nullable = true)
	private String bio;

	@Column(nullable = true)
	private String picture;

	@Column(nullable = false, unique = true)
	private String email;

	@Column(nullable = true) // nullable for OAuth users
	private String password;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Role role = Role.USER; // Default role is USER

	@Enumerated(EnumType.STRING)
	@Column(name = "auth_provider", nullable = false)
	private AuthProvider authProvider = AuthProvider.LOCAL; // Default auth is LOCAL

	@Column(name = "oauth2_id", unique = true, nullable = true) // nullable for LOCAL users
	private String oauth2Id; // Stores unique ID from OAuth2 providers

	@Column(name = "phone_number", length = 15)
	private String phoneNumber;

	@OneToMany(mappedBy = "author", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Blog> blogs;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Comment> comments;

	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Vote> votes;

	@ManyToMany(mappedBy = "tags", cascade = CascadeType.ALL)
	private List<Blog> taggedBlogs = new ArrayList<>();

	public enum AuthProvider {
		LOCAL, // For email and password users
		GOOGLE, // For Google OAuth2 users
	}

	public enum Role {
		ADMIN, // Admin users with higher privileges
		USER // Regular users
	}

	@Override
	public String toString() {
		return "UserProfile [id=" + id + ", name=" + name + ", bio=" + bio + ", picture=" + picture + ", email=" + email
				+ ", password=" + password + ", role=" + role + ", authProvider=" + authProvider + ", oauth2Id="
				+ oauth2Id + ", phoneNumber=" + phoneNumber + ", blogs=" + blogs + ", comments=" + comments
				+ comments.size() + ", votes=" + votes + ", taggedBlogs=" + taggedBlogs + "]";
	}

}
