package com.blog.serviceImpl;

import java.util.Objects;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.blog.dto.VoteDTO;
import com.blog.exception.ResourceNotFoundException;
import com.blog.mapper.VoteMapper;
import com.blog.model.Comment;
import com.blog.model.UserProfile;
import com.blog.model.Vote;
import com.blog.model.Vote.VoteType;
import com.blog.repository.CommentRepository;
import com.blog.repository.UserProfileRepository;
import com.blog.repository.VoteRepository;
import com.blog.service.IVoteService;
import com.blog.util.Util;

import jakarta.transaction.Transactional;
@Service
public class VoteServiceImpl implements IVoteService {

	private static final String VOTE_NOT_FOUND_MESSAGE = "Vote not found with id - ";
	
	private final CommentRepository commentRepository;
	private final UserProfileRepository userProfileRepository;
	private final VoteRepository voteRepository;
	
	public VoteServiceImpl(CommentRepository commentRepository, UserProfileRepository userProfileRepository,
			VoteRepository voteRepository) {
		this.commentRepository = commentRepository;
		this.userProfileRepository = userProfileRepository;
		this.voteRepository = voteRepository;
	}

	@Override
	@Transactional
	public VoteDTO doVote(VoteDTO voteDto) {
		Long currentUserId = Util.getCurrentUserId();
		// check comment in db
		Comment currentComment = commentRepository.findById(voteDto.getCommentId()).orElseThrow(
				() -> new ResourceNotFoundException("Comment not found with id - " + voteDto.getCommentId()));
		// check if you have voted or not and persist the vote accordingly
		UserProfile currentUser = userProfileRepository.findById(currentUserId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id - " + currentUserId));
		boolean isVoted = voteRepository.findByUserAndComment(currentUser, currentComment).isPresent();
		// if not voted persist the vote
		if (!isVoted) {
			Vote vote = new Vote();
			VoteMapper.dtoToEntity(voteDto, vote);
			vote.setUser(currentUser);
			vote.setComment(currentComment);
			return VoteMapper.entityToDto(voteRepository.save(vote));
		}
		// if already voted throw exception and handle with errordto
		throw new IllegalStateException("You have already voted try updating your vote");
	}

	@Override
	public VoteDTO getVote(Long id) {
		Vote vote = voteRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException(VOTE_NOT_FOUND_MESSAGE + id));
		return VoteMapper.entityToDto(vote);
	}

	@Override
	@Transactional
	public VoteDTO updateVote(VoteDTO voteDto) {
		Long currentUserId = Util.getCurrentUserId();
		// check if vote in db
		Vote currentVote = voteRepository.findById(voteDto.getId())
				.orElseThrow(() -> new ResourceNotFoundException(VOTE_NOT_FOUND_MESSAGE + voteDto.getId()));
		// check if comment in db
		Comment currentComment = commentRepository.findById(currentVote.getComment().getId()).orElseThrow(
				() -> new ResourceNotFoundException("Comment not found with id - " + currentVote.getComment().getId()));
		// check if comment id from vote entity same as comment id from dto/user input
		if (!Objects.equals(currentComment.getId(), voteDto.getCommentId())) {
			throw new IllegalStateException(
					"Entered vote id does not map with comment id...Please enter correct details");
		}
		// check user is in db
		userProfileRepository.findById(currentUserId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id - " + currentUserId));
		// check if current user is the owner of the vote
		if (!Objects.equals(currentVote.getUser().getId(), currentUserId)) {
			throw new AccessDeniedException("Vote not found in your ownership");
		}

		VoteType updatedVoteType;
		try {
			updatedVoteType = VoteType.valueOf(voteDto.getVoteType().toUpperCase());
		} catch (IllegalArgumentException ex) {
			throw new IllegalStateException("Invalid vote type provided: " + voteDto.getVoteType());
		}

		// set updated vote type to the existing vote type and the persist
		currentVote.setVoteType(updatedVoteType);
		return VoteMapper.entityToDto(voteRepository.save(currentVote));
	}

	@Override
	public String deleteVote(Long voteId) {
		Long currentUserId = Util.getCurrentUserId();
		// check vote in db
		Vote vote = voteRepository.findById(voteId)
				.orElseThrow(() -> new ResourceNotFoundException(VOTE_NOT_FOUND_MESSAGE + voteId));

		// check current user is author/owner of the vote
		if (Objects.equals(vote.getUser().getId(), currentUserId)) {
			voteRepository.deleteById(voteId);
			return "Vote deleted successfully";
		} else {
			throw new AccessDeniedException("Access denied - Vote not found in your ownership");
		}

	}

}
