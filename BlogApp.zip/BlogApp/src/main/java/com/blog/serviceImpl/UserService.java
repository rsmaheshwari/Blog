package com.blog.serviceImpl;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.blog.dto.LoginRequest;
import com.blog.dto.UserResponseDTO;
import com.blog.exception.ResourceNotFoundException;
import com.blog.mapper.UserProfileMapper;
import com.blog.model.UserProfile;
import com.blog.model.UserProfile.Role;
import com.blog.repository.UserProfileRepository;
import com.blog.util.Util;

import jakarta.transaction.Transactional;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;

@Service
public class UserService {

	@Value("${profile.picture.folder}")
	private String fileFolder;

	private final UserProfileRepository profileRepository;

	private final PasswordEncoder passwordEncoder;

	private final Validator validator;

	public UserService(UserProfileRepository profileRepository, PasswordEncoder passwordEncoder, Validator validator) {
		this.profileRepository = profileRepository;
		this.passwordEncoder = passwordEncoder;
		this.validator = validator;
	}

	// Function to validate input user data
	public String validateInputData(UserResponseDTO userResponseDTO) {
		StringBuilder message = new StringBuilder();

		Set<ConstraintViolation<UserResponseDTO>> violations = validator.validate(userResponseDTO);

		if (!violations.isEmpty()) {
			for (ConstraintViolation<UserResponseDTO> violation : violations) {
				message.append(violation.getMessage());
			}
			return message.toString();
		}
		return message.toString();
	}

	public String validateAndUploadPhoto(MultipartFile file) {
		final long MAX_FILE_SIZE = 10L * 1024 * 1024; // 10 MB
		final List<String> ALLOWED_EXTENSIONS = Arrays.asList(".jpg", ".jpeg", ".png");

		if (file.isEmpty()) {
			return "File is empty. Please upload a valid file.";
		}

		String fileName = file.getOriginalFilename();

		if (fileName == null || fileName.isEmpty()) {
			return "Invalid file name.";
		}

		// Validate file extension (ensure it's one of the allowed types)
		String fileExtension = fileName.substring(fileName.lastIndexOf("."));
		if (!ALLOWED_EXTENSIONS.contains(fileExtension)) {
			return "Max File size is 10 MB and File types supported are jpg, png, jpeg only.";
		}

		// Validate file size
		if (file.getSize() > MAX_FILE_SIZE) {
			return "File size exceeds the maximum limit of 10 MB.";
		}
		// Generate a random string for file renaming (to avoid overwriting)
		String random = UUID.randomUUID().toString().substring(0, 7);
		// Create the file path using a safe method to avoid OS-specific issues
		String filePath = Paths.get(fileFolder, random + fileExtension).toString();

		try {
			// Save the file
			Files.copy(file.getInputStream(), Paths.get(filePath));
		} catch (IOException e) {
			// Log the error for debugging purposes
			e.printStackTrace();
			return "Error uploading file.";
		}

		// Return a success message
		return "File uploaded successfully.";
	}

	@Transactional
	public String registerNewUser(UserResponseDTO profileDto) {
		UserProfile profile = new UserProfile();
		profile.setPassword(passwordEncoder.encode(profileDto.getPassword()));
		UserProfileMapper.dtoToEntity(profileDto, profile);
		if(profileDto.getRole().equalsIgnoreCase("ADMIN")) {
			profile.setRole(Role.ADMIN);
		}
		if (profileRepository.findByEmail(profile.getEmail()).isEmpty()) {
			return profileRepository.save(profile).getId().toString();
		} else {
			return "User already registered!";
		}

	}

	@Transactional
	public String registerUsingEmailPassword(LoginRequest details) {
		if (profileRepository.findByEmail(details.getEmail()).isEmpty()) {
			UserProfile profile = new UserProfile();
			profile.setEmail(details.getEmail());
			profile.setPassword(passwordEncoder.encode(details.getPassword()));
			profile.setRole(Role.USER);
			return profileRepository.save(profile).getId().toString();
		} else {
			return "User already registered";
		}
	}

	@Transactional
	public String updateUser(UserResponseDTO profileDto) {

		Long currentUserId = Util.getCurrentUserId();

		UserProfile profile = new UserProfile();
		UserProfileMapper.dtoToEntity(profileDto, profile);
		if (!Objects.equals(profileDto.getId(), currentUserId)) {
			throw new ResourceNotFoundException("Sorry you are not the owner of this profile!!");
		}

		if (profileRepository.findByEmail(profile.getEmail()).isPresent()) {
			// Logic for updating the existing user

			UserProfile existingProfile = profileRepository.findByEmail(profile.getEmail()).orElseThrow(
					() -> new ResourceNotFoundException("User not found with email - " + profile.getEmail()));
			if (!((Objects.equals(existingProfile.getEmail(), profile.getEmail()))
					&& (Objects.equals(existingProfile.getId(), currentUserId)))) {
				throw new ResourceNotFoundException("Email mismatch - Unauthorized access!!!");
			}

			// check if user updating the profile owns the profile
			if (!Objects.equals(currentUserId, existingProfile.getId())) {
				return "Access Denied to other's profile!!";
			}
			existingProfile.setPassword(passwordEncoder.encode(profileDto.getPassword()));
			existingProfile.setPicture(profile.getPicture());
			existingProfile.setRole(profile.getRole());
			existingProfile.setName(profile.getName());
			existingProfile.setBio(profile.getBio());
			existingProfile.setPhoneNumber(profile.getPhoneNumber());

			profileRepository.save(existingProfile).getId().toString();
			return "User updated successfully!!";
		} else {
			return "User not found!";
		}

	}

	public List<UserResponseDTO> allUsers() {
		return profileRepository.findAll().stream().map(UserProfileMapper::entityToResponse)
				.toList();
	}

	public String deleteUser(Long id) {
		Long userId = Util.getCurrentUserId();
		if (!Objects.equals(userId, id)) {
			throw new ResourceNotFoundException("Denied - You cannot delete someone else's profile");
		}
		profileRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id - " + id));
		profileRepository.deleteById(id);
		return "User deleted successfully";
	}
	
}