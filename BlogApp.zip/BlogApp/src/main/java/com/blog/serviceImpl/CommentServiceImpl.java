package com.blog.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.blog.dto.CommentDTO;
import com.blog.exception.ResourceNotFoundException;
import com.blog.mapper.CommentMapper;
import com.blog.model.Blog;
import com.blog.model.Comment;
import com.blog.model.UserProfile;
import com.blog.repository.BlogRepository;
import com.blog.repository.CommentRepository;
import com.blog.repository.UserProfileRepository;
import com.blog.service.ICommentService;
import com.blog.util.Util;

import jakarta.transaction.Transactional;

@Service
public class CommentServiceImpl implements ICommentService {

	private final CommentRepository commentRepository;
	private final BlogRepository blogRepository;
	private final UserProfileRepository userProfileRepository;

	public CommentServiceImpl(CommentRepository commentRepository, BlogRepository blogRepository,
			UserProfileRepository userProfileRepository) {
		this.commentRepository = commentRepository;
		this.blogRepository = blogRepository;
		this.userProfileRepository = userProfileRepository;
	}

	@Override
	@Transactional
	public CommentDTO addComment(CommentDTO commentDto) {
		Long currentUserId = Util.getCurrentUserId();
		UserProfile currentUser = userProfileRepository.findById(currentUserId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id -" + currentUserId));
		// check blog is in db
		Blog blog = blogRepository.findById(commentDto.getBlogId())
				.orElseThrow(() -> new ResourceNotFoundException("Blog not found with id -" + commentDto.getBlogId()));
		// check if parentComment given is in db
		Comment comment = new Comment();
		if (commentDto.getParentCommentId() != null) {
			Comment getById = commentRepository.findById(commentDto.getParentCommentId()).orElseThrow(
					() -> new ResourceNotFoundException("Comment not found with id - " + commentDto.getId()));
			comment.setParentComment(getById);
		} else {
			comment.setParentComment(null);
		}
		CommentMapper.dtoToEntity(commentDto, comment);
		comment.setBlog(blog);

		// set author of comment to current user
		comment.setUser(currentUser);

		// persist the comment with current time
		comment.setCreatedAt(LocalDateTime.now());
		return CommentMapper.entityToDto(commentRepository.save(comment));
	}

	@Override
	public CommentDTO getComment(Long id) {
		// any authenticated user can access any vote
		Comment comment = commentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Comment Not Found with id - " + id));
		return CommentMapper.entityToDto(comment);
	}

	@Override
	@Transactional
	public CommentDTO updateComment(CommentDTO commentDto) {

		// current user id
		Long currentUserId = Util.getCurrentUserId();

		// check if comment in db
		Comment comment = commentRepository.findById(commentDto.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Comment not found with id -" + commentDto.getId()));

		// check if current user is the author of comment
		if (!Objects.equals(comment.getUser().getId(), currentUserId)) {
			throw new AccessDeniedException("Comment is not in your ownership");
		}

		// check if the comment is already present in the given blog(avoid creating new
		// comment)
		Blog blog = blogRepository.findById(commentDto.getBlogId())
				.orElseThrow(() -> new ResourceNotFoundException("Blog not found with id -" + commentDto.getBlogId()));

		// check for parent comment in db
		if (commentDto.getParentCommentId() != null) {
			commentRepository.findById(commentDto.getParentCommentId())
					.orElseThrow(() -> new ResourceNotFoundException("Parent comment not found"));
		}

		// check if blog id is correct
		if (blog.getComments().stream().filter(c -> Objects.equals(c.getId(), comment.getId())).count() == 0) {
			throw new ResourceNotFoundException("No comment found for the given blog - Try to add new comment");
		}

		// check parent comment is not changed/mismatched from user input
		if ((comment.getParentComment() != null) && (commentDto.getParentCommentId() != null)
				&& (!Objects.equals(commentDto.getParentCommentId(), comment.getParentComment().getId()))) {
			throw new ResourceNotFoundException("Parent comment has changed");
		} else {
			comment.setCreatedAt(LocalDateTime.now());
			// set updated content to the comment
			CommentMapper.dtoToEntity(commentDto, comment);
			return CommentMapper.entityToDto(commentRepository.save(comment));
		}

	}

	@Override
	public String deleteComment(Long commentId) {
		// current user id
		Long currentUserId = Util.getCurrentUserId();
		// check if comment in db
		Comment comment = commentRepository.findById(commentId)
				.orElseThrow(() -> new ResourceNotFoundException("Comment not found with id -" + commentId));
		// check if current user is author of comment or author of the blog
		if (Objects.equals(comment.getUser().getId(), currentUserId)
				|| (Objects.equals(comment.getBlog().getAuthor().getId(), currentUserId))) {
			// delete
			commentRepository.deleteById(commentId);
			return "Comment deleted successfully";
		} else {
			throw new AccessDeniedException("Comment is not in your ownership or blog");
		}

	}

	@Override
	public List<CommentDTO> allCommentsByMe() {
		Long currentUserId = Util.getCurrentUserId();
		UserProfile myProfile = userProfileRepository.findById(currentUserId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id - " + currentUserId));
		return myProfile.getComments().stream().map(CommentMapper::entityToDto).toList();
	}

}
