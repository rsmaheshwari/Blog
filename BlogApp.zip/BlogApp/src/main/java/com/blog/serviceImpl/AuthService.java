package com.blog.serviceImpl;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import com.blog.config.UserProfileUserDetails;

@Service
public class AuthService {

	private final JwtService jwtService;
	
	private final AuthenticationManager authenticationManager;
	
	public AuthService(AuthenticationManager authenticationManager, JwtService jwtService) {
		this.authenticationManager = authenticationManager;
		this.jwtService = jwtService;
	}

	public String authenticateUser(String username, String password) {
		// Perform authentication
		Authentication authentication = authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken(username, password));

		// Retrieve user details from the authentication object
		UserProfileUserDetails userDetails = (UserProfileUserDetails) authentication.getPrincipal();

		// Return success message or JWT token
		if (authentication.isAuthenticated()) {
			return jwtService.generateToken(username,userDetails.getId());
		}
		return "Authentication Failed";
	}
}
