package com.blog.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;

import com.blog.dto.BlogDTO;
import com.blog.dto.UserResponseDTO;
import com.blog.exception.ResourceNotFoundException;
import com.blog.mapper.BlogMapper;
import com.blog.model.Blog;
import com.blog.model.UserProfile;
import com.blog.repository.BlogRepository;
import com.blog.repository.UserProfileRepository;
import com.blog.service.IBlogService;
import com.blog.specification.BlogSpecification;
import com.blog.util.Util;

import jakarta.transaction.Transactional;

@Service
public class BlogServiceImpl implements IBlogService {

	private final BlogRepository blogRepository;
	private final UserProfileRepository userProfileRepository;

	public BlogServiceImpl(BlogRepository blogRepository, UserProfileRepository userProfileRepository) {
		this.blogRepository = blogRepository;
		this.userProfileRepository = userProfileRepository;
	}

	@Override
	@Transactional
	public BlogDTO writeBlog(BlogDTO blogDto) {

		Long currentUserId = Util.getCurrentUserId();

		Blog blog = new Blog();
		BlogMapper.dtoToEntity(blogDto, blog);

		blog.setAuthor(userProfileRepository.findById(currentUserId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found.")));
		// check tagged user id to this blog and map all users tagged
		if (blogDto.getTags() != null && !blogDto.getTags().isEmpty()) {
			for (UserResponseDTO taggedPerson : blogDto.getTags()) {
				Optional<UserProfile> getById = userProfileRepository.findById(taggedPerson.getId());
				if (!getById.isEmpty()) {
					blog.getTags().add(getById.get());
				}

			}
		}
		blog.setPublishedAt(LocalDateTime.now());
		return BlogMapper.entityToDto(blogRepository.save(blog));

	}

	@Override
	public BlogDTO getBlog(Long id) {
		Blog blog = blogRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("No Blog found with ID: " + id));
		return BlogMapper.entityToDto(blog);
	}

	@Override
	@Transactional
	public BlogDTO updateBlog(BlogDTO blogDto) {
		Long currentUserId = Util.getCurrentUserId();

		if (blogDto.getId() == null) {
			throw new ResourceNotFoundException("Blog id cannot be null");
		}
		// check blog exists
		Blog blog = blogRepository.findById(blogDto.getId())
				.orElseThrow(() -> new ResourceNotFoundException("Blog not found with id - " + blogDto.getId()));
		// check if current user is the author of the blog
		if (!Objects.equals(blog.getAuthor().getId(), currentUserId)) {
			throw new AccessDeniedException("Blog is not in your ownership");
		}
		BlogMapper.dtoToEntity(blogDto, blog);
		blog.getTags().clear();
		// check tagged user id to this blog and map all users tagged
		if (blogDto.getTags() != null && !blogDto.getTags().isEmpty()) {
			for (UserResponseDTO taggedPerson : blogDto.getTags()) {
				Optional<UserProfile> getById = userProfileRepository.findById(taggedPerson.getId());
				if (!getById.isEmpty()) {
					blog.getTags().add(getById.get());
				}

			}
		}
		blog.setPublishedAt(LocalDateTime.now());
		return BlogMapper.entityToDto(blogRepository.save(blog));
	}

	@Override
	public String deleteBlog(Long blogId) {
		Long currentUserId = Util.getCurrentUserId();
		// check blog exists
		Blog blog = blogRepository.findById(blogId)
				.orElseThrow(() -> new ResourceNotFoundException("Blog not found with id - " + blogId));
		// check if current user is the author of the blog
		if (!Objects.equals(blog.getAuthor().getId(), currentUserId)) {
			throw new AccessDeniedException("Blog is not in your ownership");
		}
		blogRepository.deleteById(blogId);
		return "Blog deleted successfully";
	}

	@Override
	public List<BlogDTO> allBlogs() {
		return blogRepository.findAll().stream().map(BlogMapper::entityToDto).toList();
	}
	
	//Filter methods
	// Method to get blogs based on filters and pagination
		public Page<Blog> getBlogsByFilters(List<Long> tagIds, String searchTerm, Long authorId, String category, int page,
				int size) {
			Pageable pageable = PageRequest.of(page, size);
			return blogRepository.findAll(
					BlogSpecification.hasTags(tagIds).and(BlogSpecification.hasTextualSearch(searchTerm))
							.and(BlogSpecification.hasAuthorId(authorId)).and(BlogSpecification.hasCategory(category)),
					pageable);
		}

}
