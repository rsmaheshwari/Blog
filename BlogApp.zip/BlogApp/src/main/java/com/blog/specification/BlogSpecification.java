package com.blog.specification;

import java.util.List;

import org.springframework.data.jpa.domain.Specification;

import com.blog.model.Blog;
import com.blog.model.UserProfile;

import jakarta.persistence.criteria.Join;
import jakarta.persistence.criteria.Predicate;

public class BlogSpecification {
	public static Specification<Blog> hasAuthorId(Long authorId) {
		return (root, query, criteriaBuilder) -> criteriaBuilder.equal(root.get("author").get("id"), authorId);
	}

	public static Specification<Blog> hasCategory(String category) {
		return (root, query, criteriaBuilder) -> {
			if (category == null) {
				return criteriaBuilder.isNull(root.get("category")); // Filters out rows where category is null
			}
			return criteriaBuilder.like(criteriaBuilder.lower(root.get("category")),
					"%" + category.toLowerCase() + "%");
		};
	}

	// Specification for filtering by tags
	public static Specification<Blog> hasTags(List<Long> tagIds) {
		return (root, query, criteriaBuilder) -> {
			if (tagIds == null || tagIds.isEmpty()) {
				return criteriaBuilder.conjunction(); // Always true, no filter applied
			}

			// Join to the tags relationship
			Join<Blog, UserProfile> tagsJoin = root.join("tags");

			// Filter by tag IDs
			return tagsJoin.get("id").in(tagIds);
		};
	}

	// Specification for a textual search across title, content, and category
	public static Specification<Blog> hasTextualSearch(String searchTerm) {
		return (root, query, criteriaBuilder) -> {
			if (searchTerm == null || searchTerm.isEmpty()) {
				return criteriaBuilder.conjunction(); // No filter applied
			}

			// Perform a case-insensitive search across title, content, and category
			Predicate titlePredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("title")),
					"%" + searchTerm.toLowerCase() + "%");
			Predicate contentPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("content")),
					"%" + searchTerm.toLowerCase() + "%");
			Predicate categoryPredicate = criteriaBuilder.like(criteriaBuilder.lower(root.get("category")),
					"%" + searchTerm.toLowerCase() + "%");

			// Combine all conditions with an OR clause
			return criteriaBuilder.or(titlePredicate, contentPredicate, categoryPredicate);
		};
	}
}
