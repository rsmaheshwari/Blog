package com.blog.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.dto.LoginRequest;
import com.blog.serviceImpl.AuthService;

@RestController
@RequestMapping("/security")
public class AuthController {

	private final AuthService authService;

	// Constructor-based dependency injection
	public AuthController(AuthService authService) {
		this.authService = authService;
	}

	@PostMapping("/authenticate")
	public ResponseEntity<Object> authenticate(@RequestBody LoginRequest loginRequest) {
		String result = authService.authenticateUser(loginRequest.getEmail(), loginRequest.getPassword());
		return ResponseEntity.ok(result);
	}
}
