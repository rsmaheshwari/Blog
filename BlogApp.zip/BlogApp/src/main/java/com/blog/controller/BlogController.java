package com.blog.controller;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.blog.dto.BlogDTO;
import com.blog.model.Blog;
import com.blog.serviceImpl.BlogServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/blog")
public class BlogController {

	private final BlogServiceImpl blogService;

	public BlogController(BlogServiceImpl blogService) {
		this.blogService = blogService;
	}

	@PostMapping("/write")
	public ResponseEntity<Object> writeBlog(@Valid @RequestBody BlogDTO blogDto) {
		return new ResponseEntity<>(blogService.writeBlog(blogDto), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getBlogById(@PathVariable Long id) {
		return new ResponseEntity<>(blogService.getBlog(id), HttpStatus.OK);
	}
	
	@GetMapping({"/",""})
	public ResponseEntity<Object> getAllBlogs(){
		List<BlogDTO> allBlogs = blogService.allBlogs();
		return new ResponseEntity<>(allBlogs,HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<Object> updateBlog(@Valid @RequestBody BlogDTO blogDto) {
		return new ResponseEntity<>(blogService.updateBlog(blogDto), HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteBlog(@PathVariable Long id){
		blogService.deleteBlog(id);
		return new ResponseEntity<>("Blog deleted successfully",HttpStatus.OK);
	}
	
	@GetMapping("/filters")
    public Page<Blog> getBlogsByFilters(
            @RequestParam(required = false) List<Long> tagIds,
            @RequestParam(required = false) String searchTerm,
            @RequestParam(required = false) Long authorId,
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        
        return blogService.getBlogsByFilters(tagIds, searchTerm, authorId, category, page, size);
    }

}
