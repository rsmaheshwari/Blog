package com.blog.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.dto.VoteDTO;
import com.blog.serviceImpl.VoteServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/vote")
public class VoteController {

	private final VoteServiceImpl voteService;

	public VoteController(VoteServiceImpl voteService) {
		this.voteService = voteService;
	}

	@PostMapping("/add")
	public ResponseEntity<Object> doVote(@Valid @RequestBody VoteDTO voteDto) {
		return new ResponseEntity<>(voteService.doVote(voteDto), HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getVote(@PathVariable Long id) {
		return new ResponseEntity<>(voteService.getVote(id), HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<Object> updateVote(@Valid @RequestBody VoteDTO voteDto) {
		return new ResponseEntity<>(voteService.updateVote(voteDto), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Object> deleteVote(@PathVariable Long id) {
		return new ResponseEntity<>(voteService.deleteVote(id), HttpStatus.OK);
	}

}
