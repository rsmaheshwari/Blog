package com.blog.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.blog.dto.LoginRequest;
import com.blog.dto.UserResponseDTO;
import com.blog.serviceImpl.UserService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
public class UserController {

	private final UserService service;

	public UserController(UserService service) {
		this.service = service;
	}

	@PostMapping("/register")
	public ResponseEntity<String> registerNewUser(@Valid @RequestBody UserResponseDTO userProfileDto) {

		return new ResponseEntity<>(service.registerNewUser(userProfileDto), HttpStatus.OK);
	}

	@PostMapping("/easy-register")
	public ResponseEntity<String> registerEmailPassword(@Valid @RequestBody LoginRequest request) {
		return new ResponseEntity<>(service.registerUsingEmailPassword(request), HttpStatus.OK);
	}

	@GetMapping("/users")
	public ResponseEntity<List<UserResponseDTO>> allUsers() {
		return new ResponseEntity<>(service.allUsers(), HttpStatus.OK);
	}

	@PutMapping("/update")
	public ResponseEntity<String> updateUser(@Valid @RequestBody UserResponseDTO userResponseDTO) {
		return new ResponseEntity<>(service.updateUser(userResponseDTO), HttpStatus.OK);
	}

	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable Long id) {
		return new ResponseEntity<>(service.deleteUser(id), HttpStatus.OK);
	}

}
