package com.blog.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.blog.dto.ErrorDTO;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(JwtException.class)
	public ResponseEntity<Object> jwtExceptionHandler(JwtException ex, WebRequest request) {
		ErrorDTO errorResponse = new ErrorDTO();
		errorResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
		errorResponse.setMessage(ex.getMessage());
		errorResponse.setDescription(request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Object> validationExceptionHandler(MethodArgumentNotValidException ex, WebRequest request) {
		StringBuilder message = new StringBuilder();
		ErrorDTO errorResponse = new ErrorDTO();
		errorResponse.setStatus(HttpStatus.BAD_REQUEST.value());
		for (ObjectError err : ex.getAllErrors()) {
			message.append(err.getDefaultMessage() + ". ");
		}

		errorResponse.setMessage(message.toString());
		errorResponse.setDescription(request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Object> resourceNotFoundExceptionHandler(ResourceNotFoundException ex, WebRequest request) {
		ErrorDTO errorResponse = new ErrorDTO(ex.getMessage(), HttpStatus.NOT_FOUND.value(),
				request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(AuthorizationDeniedException.class)
	public ResponseEntity<Object> authorizationDeniedExceptionHandler(AuthorizationDeniedException ex, WebRequest request) {
		ErrorDTO errorResponse = new ErrorDTO(ex.getMessage(), HttpStatus.BAD_REQUEST.value(),
				request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(AccessDeniedException.class)
	public ResponseEntity<Object> accessDeniedExceptionHandler(AccessDeniedException ex, WebRequest request) {
		ErrorDTO errorResponse = new ErrorDTO(ex.getMessage(), HttpStatus.BAD_REQUEST.value(),
				request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(IllegalStateException.class)
	public ResponseEntity<Object> illegalStateExceptionHandler(IllegalStateException ex, WebRequest request) {
		ErrorDTO errorResponse = new ErrorDTO(ex.getMessage(), HttpStatus.BAD_REQUEST.value(),
				request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
}
