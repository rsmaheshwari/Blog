package com.blog.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class VoteDTO {

	private Long id;
	@NotNull
	@Pattern(regexp = "UPVOTE|DOWNVOTE", message = "Vote type must be UPVOTE or DOWNVOTE")
	private String voteType; // "UPVOTE" or "DOWNVOTE"
	private Long userId; // User ID who voted
	@NotNull
	private Long commentId; // Comment ID on which vote is placed
}