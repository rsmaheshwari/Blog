package com.blog.dto;

import java.time.LocalDateTime;
import java.util.List;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class BlogDTO {

    private Long id;
    @NotNull
    @Size(min = 5, max = 50, message = "Title length should be between 5 to 50 characters")
    private String title;
    @NotNull
    @Size(min = 5, max = 2000, message = "Content length should be between 5 to 2000 characters")
    private String content;
    @Size(min = 3, max = 50, message = "Category length should be between 5 to 15 characters or null")
    private String category;
    private Boolean isDraft;
    private LocalDateTime publishedAt;
    private UserResponseDTO author;
    private List<UserResponseDTO> tags;
    private List<CommentDTO> comments;
}