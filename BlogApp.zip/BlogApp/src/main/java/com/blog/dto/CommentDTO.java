package com.blog.dto;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class CommentDTO {

    private Long id;
    @NotNull
    @Size(min = 5, max = 50, message = "Content length should be between 5 to 50 characters")
    private String content;
    private LocalDateTime createdAt;
    @NotNull
    private Long blogId; // Blog ID for reference
    @JsonIgnore
    private UserResponseDTO user; // User who created the comment
    private Long parentCommentId; // Parent comment ID if it's a reply
    private List<CommentDTO> replies; // Nested replies
    private List<VoteDTO> votes; // Votes on the comment
}