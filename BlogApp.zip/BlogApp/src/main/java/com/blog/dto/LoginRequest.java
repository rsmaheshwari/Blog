package com.blog.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest {
	@NotNull
	@Email
	@Pattern(regexp = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$", message = "Invalid email format.")
	@Size(min = 4, max = 25,message = "Email can not be empty")
    private String email;
    @NotNull
    @Size(min = 8, max = 16, message = "Password length should be between 8 to 16 characters")
    private String password;
}

