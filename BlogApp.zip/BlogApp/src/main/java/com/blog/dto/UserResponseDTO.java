package com.blog.dto;

import java.util.ArrayList;
import java.util.List;

import com.blog.model.UserProfile.AuthProvider;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserResponseDTO {

	private Long id;// user id
	@NotNull
	@Size(min = 2, max = 25, message = "Name length should be between 2 to 25 characters")
	private String name;
	private String bio;
	private String picture;
	@NotNull(message = "Email is required")
	@Email(message = "Invalid email format")
	@Pattern(regexp = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$", message = "Invalid email format")
	private String email;
	@NotNull
	@Size(min = 8, max = 16, message = "Password length should be between 8 to 16 characters")
	private String password;
	@NotNull
	private String role ; // Default role is USER
	private AuthProvider authProvider;
	private String oauth2Id; // Stores unique ID from OAuth2 providers
	@Size(max = 15)
	private String phoneNumber;
	private List<BlogDTO> blogsDto = new ArrayList<>();
	private List<CommentDTO> commentsDto = new ArrayList<>();
	private List<VoteDTO> voteDto = new ArrayList<>();
	private List<BlogDTO> taggedBlogs = new ArrayList<>();
}
