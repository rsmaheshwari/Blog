package com.blog.mapper;

import java.util.ArrayList;

import org.springframework.stereotype.Component;

import com.blog.dto.BlogDTO;
import com.blog.dto.CommentDTO;
import com.blog.dto.UserResponseDTO;
import com.blog.model.Blog;
@Component
public class BlogMapper {
	
	public static void dtoToEntity(BlogDTO dto, Blog entity) {
		entity.setTitle(dto.getTitle());
		entity.setContent(dto.getContent());
		entity.setCategory(dto.getCategory());
		entity.setIsDraft(dto.getIsDraft());
	}

	public static BlogDTO entityToDto(Blog entity) {
		BlogDTO dto = new BlogDTO();
		dto.setId(entity.getId());
		dto.setTitle(entity.getTitle());
		dto.setContent(entity.getContent());
		dto.setCategory(entity.getCategory());
		dto.setIsDraft(entity.getIsDraft());
		dto.setPublishedAt(entity.getPublishedAt());
		dto.setAuthor(UserProfileMapper.entityToResponse(entity.getAuthor()));
		// check null and then assign dto
		dto.setTags(entity.getTags() != null
				? entity.getTags().stream().map(UserProfileMapper::entityToResponse).toList()
				: new ArrayList<UserResponseDTO>());
		dto.setComments(entity.getComments() != null
				? entity.getComments().stream().map(CommentMapper::entityToDto).toList()
				: new ArrayList<CommentDTO>());
		return dto;
	}

}
