package com.blog.mapper;

import java.util.ArrayList;

import com.blog.dto.CommentDTO;
import com.blog.dto.VoteDTO;
import com.blog.model.Comment;

public class CommentMapper {

	public static void dtoToEntity(CommentDTO dto, Comment entity) {
		entity.setContent(dto.getContent());
	}

	public static CommentDTO entityToDto(Comment entity) {
		CommentDTO dto = new CommentDTO();
		dto.setId(entity.getId());
		dto.setBlogId(entity.getBlog().getId());
		dto.setUser(UserProfileMapper.entityToResponse(entity.getUser()));
		dto.setContent(entity.getContent());
		dto.setCreatedAt(entity.getCreatedAt());
		// check null then assign dto
		dto.setReplies(entity.getReplies() != null
				? entity.getReplies().stream().map(reply -> CommentMapper.entityToDto(entity)).toList()
				: new ArrayList<CommentDTO>());

		dto.setVotes(entity.getVotes() != null
				? entity.getVotes().stream().map(VoteMapper::entityToDto).toList()
				: new ArrayList<VoteDTO>());
		
		dto.setParentCommentId(entity.getParentComment()!=null?entity.getParentComment().getId():null);
		return dto;
	}

}
