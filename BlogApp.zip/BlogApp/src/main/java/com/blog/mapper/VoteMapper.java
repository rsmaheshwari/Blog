package com.blog.mapper;

import com.blog.dto.VoteDTO;
import com.blog.model.Vote;
import com.blog.model.Vote.VoteType;

public class VoteMapper {
	
	public static void dtoToEntity(VoteDTO dto,Vote entity) {
		if(dto.getVoteType().equalsIgnoreCase("UPVOTE")) {
			entity.setVoteType(VoteType.UPVOTE);
		}
		if(dto.getVoteType().equalsIgnoreCase("DOWNVOTE")) {
			entity.setVoteType(VoteType.DOWNVOTE);
		}
	}

	public static VoteDTO entityToDto(Vote entity) {
		VoteDTO dto = new VoteDTO();
		dto.setId(entity.getId());
		dto.setVoteType(entity.getVoteType().toString());
		dto.setUserId(entity.getUser().getId());
		dto.setCommentId(entity.getComment().getId());
		return dto;
	}
}
