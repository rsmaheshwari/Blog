package com.blog.mapper;

import org.springframework.stereotype.Component;

import com.blog.dto.UserResponseDTO;
import com.blog.model.UserProfile;
import com.blog.model.UserProfile.AuthProvider;

@Component
public class UserProfileMapper {

	public static void dtoToEntity(UserResponseDTO profileDto, UserProfile entity) {
		entity.setEmail(profileDto.getEmail());
		entity.setAuthProvider(AuthProvider.LOCAL);
		entity.setBio(profileDto.getBio());
		entity.setName(profileDto.getName());
		entity.setPhoneNumber(profileDto.getPhoneNumber());
		entity.setPicture(profileDto.getPicture());
		entity.setOauth2Id(null);

	}

	public static UserResponseDTO entityToResponse(UserProfile entity) {
		UserResponseDTO response = new UserResponseDTO();
		response.setId(entity.getId());
		response.setName(entity.getName());
		response.setBio(entity.getBio());
		response.setPicture(entity.getPicture());
		response.setEmail(entity.getEmail());
		response.setPassword("********");
		response.setRole(entity.getRole().toString());
		response.setAuthProvider(entity.getAuthProvider());
		response.setOauth2Id(entity.getOauth2Id());
		response.setPhoneNumber(entity.getPhoneNumber());
		return response;
	}

}
