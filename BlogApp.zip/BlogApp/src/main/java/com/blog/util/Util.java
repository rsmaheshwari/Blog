package com.blog.util;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import com.blog.config.UserProfileUserDetails;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class Util {

	public static Object jsonToObject(String json, Object o) {
		ObjectMapper mapper = new ObjectMapper();
		Object object = null;
		try {
			object = mapper.readValue(json, o.getClass());
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		return object;
	}

	public static Long getCurrentUserId() {
		UserProfileUserDetails currentUser = (UserProfileUserDetails) SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();
		return currentUser.getId();
	}

}
