package com.blog.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.blog.model.Blog;
import com.blog.model.UserProfile;

@Repository
public interface BlogRepository extends JpaRepository<Blog, Long>, JpaSpecificationExecutor<Blog> {
	List<Blog> findByIsDraftFalse(); // Fetch all published blogs

	List<Blog> findByAuthor(UserProfile author); // Find blogs by author

	List<Blog> findByCategory(String category); // Find blogs by category

	Optional<Blog> findByIdAndIsDraftFalse(Long id); // Fetch a published blog by id
}
