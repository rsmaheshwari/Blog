package com.blog.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.blog.model.Blog;
import com.blog.model.Comment;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommentRepository extends JpaRepository<Comment, Long> {
    List<Comment> findByBlog(Blog blog); // Find comments by blog
    Optional<Comment> findByIdAndBlogId(Long commentId, Long blogId); // Find comment by ID and blog ID
}
