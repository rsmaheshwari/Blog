package com.blog.service;

import java.util.List;

import com.blog.dto.BlogDTO;

public interface IBlogService {

	BlogDTO writeBlog(BlogDTO jsonDto);

	BlogDTO getBlog(Long id);

	BlogDTO updateBlog(BlogDTO jsonDto);

	String deleteBlog(Long blogId);

	List<BlogDTO> allBlogs();
}
