package com.blog.service;

import com.blog.dto.VoteDTO;

public interface IVoteService {
	VoteDTO doVote(VoteDTO jsonDto);

	VoteDTO getVote(Long id);

	VoteDTO updateVote(VoteDTO jsonDto);

	String deleteVote(Long voteId);
}
