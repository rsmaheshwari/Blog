package com.blog.service;

import java.util.List;

import com.blog.dto.CommentDTO;

public interface ICommentService {

	CommentDTO addComment(CommentDTO jsonDto);

	CommentDTO getComment(Long id);

	CommentDTO updateComment(CommentDTO jsonDto);

	String deleteComment(Long commentId);
	
	List<CommentDTO> allCommentsByMe();
}
